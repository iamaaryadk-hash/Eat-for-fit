# Eat For Fit — first website version

Open `index.html` in a browser to view the website.

Files:
- index.html — page structure/content
- style.css — responsive styling

You can replace the placeholder address, phone number, email, prices, and menu items with the real café information.
